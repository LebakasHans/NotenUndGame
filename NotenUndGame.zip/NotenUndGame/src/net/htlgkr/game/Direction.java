package net.htlgkr.game;

public enum Direction {
    UP, RIGHT, DOWN, LEFT
}
